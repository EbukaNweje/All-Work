import React from 'react'

function Blog() {
  return (
    <div>
      this is blog
    </div>
  )
}

export default Blog
