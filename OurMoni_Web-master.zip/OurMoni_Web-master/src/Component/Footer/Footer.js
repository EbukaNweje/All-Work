import React from 'react'

function Footer() {
  return (
    <div>
      this is footer
    </div>
  )
}

export default Footer
