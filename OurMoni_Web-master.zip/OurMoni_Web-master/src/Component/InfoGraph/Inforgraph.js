import React from 'react'

function Inforgraph() {
  return (
    <div>
      this is  footer
    </div>
  )
}

export default Inforgraph
