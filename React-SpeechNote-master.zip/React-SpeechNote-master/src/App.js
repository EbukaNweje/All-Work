import logo from "./logo.svg";
import "./App.css";
import HomeSceen from "./Components/HomeSceen";
import TalkSpeech from "./Microphone/TalkSpeech";

function App() {
  return (
    <div>
      {/* <HomeSceen /> */}
      <TalkSpeech />
    </div>
  );
}

export default App;
