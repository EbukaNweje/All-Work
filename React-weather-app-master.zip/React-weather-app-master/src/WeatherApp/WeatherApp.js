import React from "react";
import styled from "styled-components";

function WeatherApp() {
  return (
    <div>
      <Container>dfghxm</Container>
    </div>
  );
}

export default WeatherApp;

const Container = styled.div``;
