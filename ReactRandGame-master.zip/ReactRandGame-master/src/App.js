import Comp from "./Comp/Comp";


function App() {
  return (
    <div >
      <Comp/>
    </div>
  );
}

export default App;
