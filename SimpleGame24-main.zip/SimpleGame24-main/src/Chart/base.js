import firebase from "firebase";
import "firebase/firestore";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyDvNZhAkgrYwEHciswePRg6Yaer-qHbVHQ",
  authDomain: "codelab-movies.firebaseapp.com",
  projectId: "codelab-movies",
  storageBucket: "codelab-movies.appspot.com",
  messagingSenderId: "400690718211",
  appId: "1:400690718211:web:a0e14d1a836ae55b445036",
});
