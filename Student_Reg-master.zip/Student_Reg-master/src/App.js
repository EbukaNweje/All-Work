import ViewStudents from "./View/ViewStudents";


function App() {
  return (
    <div>
      <center>
        <ViewStudents />
      </center>
    </div>
  );
}

export default App;
