import firebase from "firebase"
import "firebase/firestore"
import "firebase/storage"


export const app = firebase.initializeApp({
  apiKey: "AIzaSyBIFAR7iERJaF7-rjj0xl_i0jUoj7kaH-s",
  authDomain: "codelab-admission.firebaseapp.com",
  projectId: "codelab-admission",
  storageBucket: "codelab-admission.appspot.com",
  messagingSenderId: "640840343091",
  appId: "1:640840343091:web:bd8ed03471380307d04d46"
})