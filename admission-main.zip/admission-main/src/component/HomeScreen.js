import React from 'react'
import Home from './Home'

const HomeScreen = () => {
  return (
    <div>
      <div
      style={{
        display:"flex",
        justifyContent:"center",
        flexWrap:'center',
        marginTop:"40px"
      }}
      >
        <Home />
      </div>
   
    </div>
  )
}

export default HomeScreen
