import firebase from "firebase";
import "firebase/firestore";
import "firebase/auth";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyBqb5W3YP_hx24FYPn8z8P2roahe6QYUI4",
  authDomain: "giddystalk-auth.firebaseapp.com",
  projectId: "giddystalk-auth",
  storageBucket: "giddystalk-auth.appspot.com",
  messagingSenderId: "46603937435",
  appId: "1:46603937435:web:eca45b0582c4ea4d6d083e",
});
