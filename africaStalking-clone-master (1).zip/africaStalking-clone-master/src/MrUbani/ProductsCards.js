import React from "react";
import "./prod.css";

function ProductsCards() {
  return <div>this is the product cards</div>;
}

export default ProductsCards;
