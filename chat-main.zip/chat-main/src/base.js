import firebase from "firebase";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyAu-PtJkE9EZtlGwPygehLL_M4tyeYux58",
  authDomain: "lets-chat-again.firebaseapp.com",
  projectId: "lets-chat-again",
  storageBucket: "lets-chat-again.appspot.com",
  messagingSenderId: "1072813093669",
  appId: "1:1072813093669:web:b8c78b6b1cc40860ab60cc"
})