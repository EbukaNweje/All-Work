import React from "react";
import WorkHome from "./component/WorkHome";

const App = () => {
  return (
    <div>
      <WorkHome />
    </div>
  );
};
export default App;
