import React from "react";

const Peter = () => {
  return <div>THis is a Test file</div>;
};

export default Peter;
