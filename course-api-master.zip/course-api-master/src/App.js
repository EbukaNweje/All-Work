import React from 'react';

function App() {
  return <h1>Course API</h1>;
}

export default App;
