const sr = ScrollReveal({
    origin: 'top',
    distance: '100px',
    duration: 1500,
    reset: true,
})

sr.reveal('.section__box', {interval: 200,})