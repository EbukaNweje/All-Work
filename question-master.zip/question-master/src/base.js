import firebase from "firebase"
import "firebase/firestore"


export const app = firebase.initializeApp({
  apiKey: "AIzaSyBB5vq95NlX32HaKS0Lvai0JIETRDbLKgg",
    authDomain: "lofty-work.firebaseapp.com",
    projectId: "lofty-work",
    storageBucket: "lofty-work.appspot.com",
    messagingSenderId: "412472425102",
    appId: "1:412472425102:web:d55565ff31cd1708b8a7df"
})