import React from "react";

const AboutPage = () => {
  return (
    <div id="about">
      <div
        style={{
          height: "600px",
          width: "100%",
          backgroundColor: "coral",
          color: "white",
        }}
      >
        about
      </div>
    </div>
  );
};

export default AboutPage;
