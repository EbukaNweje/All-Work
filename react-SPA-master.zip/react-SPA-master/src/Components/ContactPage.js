import React from "react";

const ContactPage = () => {
  return (
    <div id="contact">
      <div
        style={{
          height: "600px",
          width: "100%",
          backgroundColor: "lightgray",
          color: "white",
        }}
      >
        contact
      </div>
    </div>
  );
};

export default ContactPage;
