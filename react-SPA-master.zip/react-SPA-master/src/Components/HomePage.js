import React from "react";

const HomePage = () => {
  return (
    <div id="home">
      <div
        style={{
          height: "600px",
          width: "100%",
          backgroundColor: "black",
          color: "white",
        }}
      >
        home
      </div>
    </div>
  );
};

export default HomePage;
