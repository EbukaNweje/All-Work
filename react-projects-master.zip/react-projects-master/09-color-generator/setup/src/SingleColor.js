import React, { useState, useEffect } from 'react'
import rgbToHex from './utils'

const SingleColor = () => {
  return <h4>single color</h4>
}

export default SingleColor
