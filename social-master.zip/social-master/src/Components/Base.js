import firebase from "firebase";
import "firebase/firestore";
import "firebase/auth";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyAXJjqriYH8ZFxUx87xC8-CyJ1TBXqoCME",
  authDomain: "facebook-clone-d9d98.firebaseapp.com",
  projectId: "facebook-clone-d9d98",
  storageBucket: "facebook-clone-d9d98.appspot.com",
  messagingSenderId: "312160563089",
  appId: "1:312160563089:web:ea3ae5bcccc6dd24b3f430",
});
