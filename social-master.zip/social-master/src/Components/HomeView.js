import React from "react";

function HomeView() {
  return <div>this is where all the post will be</div>;
}

export default HomeView;
