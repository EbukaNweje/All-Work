import firebase from "firebase"
import "firebase/firestore"
import "firebase/auth"


export const app = firebase.initializeApp({
  apiKey: "AIzaSyARrEi31xfEG6QMaJWPu9AggEhNENqW99k",
  authDomain: "lofty-project.firebaseapp.com",
  projectId: "lofty-project",
  storageBucket: "lofty-project.appspot.com",
  messagingSenderId: "524122905579",
  appId: "1:524122905579:web:744339a992535b86dcd7ae"
})  





// apiKey: "AIzaSyBB5vq95NlX32HaKS0Lvai0JIETRDbLKgg",
//   authDomain: "lofty-work.firebaseapp.com",
//   projectId: "lofty-work",
//   storageBucket: "lofty-work.appspot.com",
//   messagingSenderId: "412472425102",
//   appId: "1:412472425102:web:d55565ff31cd1708b8a7df"