import React from "react";
import HomeScreen from "../HomeScreen/HomeScreen";

const Body = () => {
  return (
    <div>
      <HomeScreen />
    </div>
  );
};

export default Body;
