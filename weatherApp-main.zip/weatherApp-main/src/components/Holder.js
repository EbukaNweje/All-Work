import React from "react";
import AddEntry from "./Add/AddEntry";
import Header from "./Header.js/Header";

function Holder() {
  return (
    <>
      <Header />
    </>
  );
}

export default Holder;

// <AddEntry />
