import React from "react";

const AboutMe = () => {
  return (
    <div>
      <div>This is all About me</div>
    </div>
  );
};

export default AboutMe;
